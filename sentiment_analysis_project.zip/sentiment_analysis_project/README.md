# Twitter Sentiment Analysis

A deep learning project for sentiment analysis on Twitter data using transformer-based models. This project implements a custom transformer architecture to classify sentiment in tweets and extract relevant entities.

## Overview

This project focuses on sentiment analysis of Twitter data using a custom transformer model. The model is trained to classify tweets into positive, negative, or neutral sentiment categories. The implementation includes:

- Custom transformer architecture with multi-head attention
- SentencePiece tokenization for text preprocessing
- Data cleaning and preprocessing pipeline
- Training and evaluation workflows
- Visualization of training metrics and results

The model is designed to understand the nuanced language used in social media, including emojis, hashtags, and informal text structures.

## Dataset

The project uses the following datasets:
- Twitter Entity Sentiment Analysis dataset
- Tweet Sentiment Extraction dataset

These datasets contain tweets with labeled sentiment and entity information, allowing for both sentiment classification and entity extraction tasks.

## Requirements

To run this project, you'll need the following dependencies:

```
torch
pandas
numpy
matplotlib
seaborn
nltk
sentencepiece
datasets
scikit-learn
tqdm
emoji
kagglehub (for dataset download)
```

A complete list of dependencies is available in the `requirements.txt` file.

## Project Structure

```
sentiment_analysis_project/
├── data/
│   └── README.md                # Instructions for downloading datasets
├── models/
│   ├── transformer.py           # Transformer model implementation
│   └── tokenizer.py             # SentencePiece tokenizer wrapper
├── utils/
│   ├── data_processing.py       # Data cleaning and preprocessing functions
│   ├── training.py              # Training utilities
│   └── visualization.py         # Visualization functions
├── notebooks/
│   └── sentiment_analysis.ipynb # Main notebook with full workflow
├── scripts/
│   ├── train.py                 # Training script
│   └── evaluate.py              # Evaluation script
├── examples/
│   └── example_predictions.md   # Example model predictions
├── requirements.txt             # Project dependencies
└── README.md                    # This file
```

## Setup and Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/sentiment_analysis_project.git
   cd sentiment_analysis_project
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Download the datasets:
   - The datasets can be downloaded using the Kaggle API or directly from the Kaggle website
   - Place the datasets in the `data/` directory
   - Alternatively, use the `kagglehub` package as shown in the notebook:
     ```python
     import kagglehub
     path = kagglehub.dataset_download("jp797498e/twitter-entity-sentiment-analysis")
     ```

## Usage

### Training the Model

To train the model with default parameters:

```python
from models.transformer import SentimentTransformer
from utils.training import train_model

# Initialize model
model = SentimentTransformer(
    vocab_size=12000,
    dim_model=256,
    dim_feedforward=1024,
    num_layers=16,
    dropout=0.1,
    max_len=512
)

# Train model
train_model(model, train_dataloader, val_dataloader, epochs=10)
```

### Making Predictions

```python
def predict_sentiment(text, model, tokenizer):
    # Preprocess and tokenize text
    tokens = tokenizer.encode(text)
    
    # Convert to tensor and get prediction
    inputs = torch.tensor([tokens]).to(model.device)
    with torch.no_grad():
        outputs = model(inputs)
    
    # Get predicted sentiment
    sentiment_id = torch.argmax(outputs, dim=1).item()
    sentiment_map = {0: "negative", 1: "neutral", 2: "positive"}
    return sentiment_map[sentiment_id]

# Example usage
text = "I love this new feature! It's amazing!"
sentiment = predict_sentiment(text, model, tokenizer)
print(f"Sentiment: {sentiment}")
```

## Model Architecture

The sentiment analysis model is based on a transformer architecture with the following components:

- Embedding layer with positional encoding
- Multi-head attention mechanism
- Feed-forward neural networks
- Layer normalization
- Dropout for regularization

The model processes tokenized text and outputs sentiment probabilities for each class (negative, neutral, positive).

## Performance

The model achieves the following performance metrics on the validation set:

- Accuracy: ~85%
- F1 Score: ~84%
- Precision: ~83%
- Recall: ~85%

## Visualizations

The project includes various visualizations to help understand the data and model performance:

- Sentiment distribution in the dataset
- Training and validation loss curves
- Confusion matrix for model predictions
- Attention weights visualization

## Future Work

Potential improvements and extensions to this project:

- Fine-tuning with more recent Twitter data
- Implementing more advanced transformer architectures (e.g., BERT, RoBERTa)
- Adding support for multi-language sentiment analysis
- Developing a web interface for real-time sentiment analysis

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- The Twitter Entity Sentiment Analysis dataset creators
- SentencePiece tokenizer developers
- PyTorch team for the deep learning framework
